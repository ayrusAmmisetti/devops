package com.devopsproject.devopspro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevopsproApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevopsproApplication.class, args);
	}

}
